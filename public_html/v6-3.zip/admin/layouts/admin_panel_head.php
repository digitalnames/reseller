<div class="fix full border_box div_mid pt_20 pr_10 pb_20 pl_10 bg_very_light_ash">
	<a href="#"><h1 class="fs_30 lh_40 font_bold text_dark_ash"><?php echo $company_name; ?></h1></a>
</div>