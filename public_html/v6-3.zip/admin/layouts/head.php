<div class="fix half floatleft">
	<a href="index.php"><h1 class="fs_30 lh_40 font_bold text_dark_ash pl_20 pr_20"><?php echo $company_name; ?></h1></a>
</div>
<!-- <div class="fix half floatright">
	<?php if(isset($_SESSION['login_token'])){ ?>
	<a href="logout.php" class="floatright"><p class="fs_14 lh_22 font_bold text_dark_ash pl_20 pr_20">Logout</p></a>			
	<a href="control_panel.php" class="floatright"><p class="fs_14 lh_22 font_bold text_dark_ash pl_20 pr_20">Control Panel</p></a>
	<?php }else{ ?>
	<a href="login.php" class="floatright"><p class="fs_14 lh_22 font_bold text_dark_ash pl_20 pr_20">Login</p></a>
	<?php } ?>
</div>
 -->